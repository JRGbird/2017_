void generate_chart_header();
void generate_chart_node(char* name, char* boss, int score);
void generate_chart_footer();
